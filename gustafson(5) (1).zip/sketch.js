var a= 450;
var b= 332;
var radius= 15;

var w= 120;
var x= 130; 
var y= 360;
var z= 175;

value=3
let button;
  
function setup() {
  createCanvas(600, 400);
  ellipseMode(RADIUS);
  ellipse(a,b, radius, radius);
  
  button= createButton('On/Off');
  button.position(430,370);
  button.mousePressed(changeBG);
}
function changeBG(){
  let val= random(255);
  background(val);
}

function draw() {
  background(204, 226, 225);
  strokeWeight(8);
  rect(100, 110, 400, 250);    
  line(100, 30, 300, 110);
  line(500, 30, 300, 110);

  strokeWeight(3);
  fill(202,189,255,100);
  rect(280, 325, 30,20);
  
  strokeWeight(3);
  ellipse(a,b,radius, radius);

  rect(w,x,y,z);
  if(mouseIsPressed){
    stroke(3);
  fill(172,208,232,91);
  }else{
    stroke(3)
    fill(255,193,189,100);
  }
  ellipse(a-300,b,radius, radius); 
 
     var d=dist(mouseX, mouseY, a, b);
    if(keyIsPressed){
      if(key== 'a'){
        if(d<radius)
          radius++;
        fill(220,255,189,230);
      }else{
        fill (225);
      }   
  
    }
  ellipse(a,b,radius, radius);
  
 if((mouseX>280)&&(mouseX<280+30)&&
 (mouseY>325)&&(mouseY<325+20)){
  fill(255,193,122,255);
  }
  else{
  fill(255);
  }
  rect(280,325,30,20);
    
}
  
