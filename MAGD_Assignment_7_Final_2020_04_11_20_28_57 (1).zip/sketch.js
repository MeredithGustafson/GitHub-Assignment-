var num= 60;
var x= [];
var y= [];
var easing =0.01;

function setup() {
  createCanvas(400, 400);
  noStroke();
  background(128,85,27,50);
  for (var i=0; i< num;i++){
    x[i]=0;
    print(x.length);
    y[i]=0;
    print(y.length);
  }
}

function draw() {
  for (var i= num-1; i >0; i--){
    x[i]=x[i-1];
    y[i]=y[i-1];
  }
  x[0]= mouseX;
  y[0]= mouseY;
  for(var i =0; i< num; i++){
    fill(i*106,207,95,81,0);
  ellipse(x[i],y[i], 20, 40);
    fill(i*4);
	line(200, 275);
    print(x + ":" + x);
  
 //left tree 
 fill(128,104,27,50);
  rect(95,234,20,160);
  fill(76,196,50,77);
  ellipse(105,175,120,120);
  
  //right tree
  fill(128,104,27,50);
  rect(295,234,20,160);
  fill(76,196,50,77);
  ellipse(305,175,120,120);
  
    //leaves 
  fill(237,181,45,93);
    ellipse(10,380,10,20);
    ellipse(58, 370,10,20);
    ellipse(35,230,10,20);
    ellipse(65,255,10,20);
    
  fill(67,144,15,56);
    ellipse(180,280,10,20);
    ellipse(200,200,10,20);
    ellipse(220,300, 10,20);
    ellipse(260, 250,10,20);
    ellipse(160, 370,10,20);
    ellipse(270, 380,10,20);
    
   fill(237,190,45,93);
    ellipse(300,350,10,20);
    ellipse(350,380,10,20);
    ellipse(380,300,10,20);
    //grass
   fill(15,112,54,44);
    rect(0,380,400,20);
  }
}