function setup() {
  createCanvas(351, 400);
  background(87);
}

function draw(){
  strokeWeight(4);
  stroke(60);
  fill(20);
  strokeWeight(7);
  strokeCap(ROUND);
  rect(0,200,50, 600)
  rect(200,330,50, 300)
  rect(300,200,50, 600)
  rect(100,330,50, 300)
  rect(50,100,50, 700)
  rect(250,100,50, 700)
  
  strokeWeight(2);
  stroke(167);
  fill(225);
  ellipse(50, 46, 55, 55);

  noFill();
  rect(150,50,50, 800)
  
  strokeWeight(4)
  stroke(250)
  point(20, 150);
  point(30, 120);
  point(100, 20);
  point(110, 200);
  point(132, 250);
  point(130, 100);
  point(140, 30);
  point(170, 40);
  point(210, 30);
  point(220, 250);
  point(230,200);
  point(260, 40);
  point(250, 80);
  point(300, 90);
  point(310, 20);
  point(340, 70);
  point(399, 120); 
}

